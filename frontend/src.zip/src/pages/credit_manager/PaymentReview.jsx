import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getCookie } from "../../utils/csrf";
import logo from "../../assets/mylora-logo.png";
import "./PaymentReview.css";


export default function PaymentReview() {
  const navigate = useNavigate();
  const { paymentId } = useParams();
  const [payment, setPayment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [password, setPassword] = useState("");
  const [pendingAction, setPendingAction] = useState(null); // 'approve' or 'reject'

  useEffect(() => {
    fetch(`http://localhost:8000/api/cm/payment/${paymentId}/`, { 
      credentials: "include",
    })
      .then((res) => {
        if (!res.ok) throw new Error("Failed to load payment");
        return res.json();
      })
      .then(setPayment)
      .catch((err) => {
        console.error(err);
        alert("Failed to load payment details");
        navigate("/credit-manager/dashboard");
      })
      .finally(() => setLoading(false));
  }, [paymentId, navigate]);

  const initiateAction = (action) => {
    setPendingAction(action);
    setShowPasswordModal(true);
    setPassword("");
  };

  const handleConfirmAction = async () => {
    if (!password) {
      alert("Please enter your password");
      return;
    }

    setProcessing(true);
    const csrfToken = getCookie("csrftoken");

    try {
      const response = await fetch(
        `http://localhost:8000/api/cm/payment/${paymentId}/${pendingAction}/`,
        {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
            "X-CSRFToken": csrfToken,
          },
          body: JSON.stringify({ password }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to ${pendingAction} payment`);
      }

      setShowPasswordModal(false);
      if (pendingAction === "approve") {
        setShowSuccessModal(true);
      } else {
        alert("Payment rejected");
        navigate("/credit-manager/dashboard");
      }
    } catch (err) {
      console.error(err);
      alert(err.message || `Failed to ${pendingAction} payment`);
    } finally {
      setProcessing(false);
    }
  };

  const handleCancelPasswordModal = () => {
    setShowPasswordModal(false);
    setPassword("");
    setPendingAction(null);
  };

  if (loading) {
    return <div className="payment-review-container">Loading...</div>;
  }

  if (!payment) {
    return <div className="payment-review-container">Payment not found</div>;
  }

  const creditUtilization = payment.credit_limit
    ? ((parseFloat(payment.credit_limit) - parseFloat(payment.available_credit)) /
        parseFloat(payment.credit_limit)) *
      100
    : 0;


  return (
    <div className="payment-review-container">
      {/* HEADER */}
      <header className="payment-header-section">
        <div className="payment-brand-group">
          <img src={logo} alt="Mylora Logo" className="mylora-logo" />
          <span className="payment-system-title">Web Credit System</span>
        </div>
        <button className="payment-logout-btn" onClick={() => navigate("/login")}>
          Logout
        </button>
      </header>

      <main className= "payment-content">
    
      {/*<h1 className="payment-title">Payment Review</h1>*/}
      <h2 className="payment-customer-name">{payment.customer_name}</h2>

      {/* Credit Balance Section */}
      <section className="credit-section">
        <h3 className="section-title">Credit Balance</h3>
        <div className="credit-row">
          <span>Available Credit:</span>
          <span className="credit-value">
            ₱ {parseFloat(payment.available_credit).toLocaleString("en-PH", {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </span>
        </div>

        <div className="progress-container">
          <div
            className="progress-bar"
            style={{ width: `${creditUtilization}%` }}
          />
        </div>

        <div className="credit-row">
          <span>Credit Limit:</span>
          <span>
            ₱ {parseFloat(payment.credit_limit).toLocaleString("en-PH", {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </span>
        </div>
      </section>

      {/* Outstanding Balance */}
      <div className="balance-section">
        <div className="balance-row">
          <span className="balance-label">Outstanding Balance</span>
          <span className="balance-amount">
            ₱ {parseFloat(payment.outstanding_balance).toLocaleString("en-PH", {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </span>
        </div>
      </div>

      {/* Payment Form Fields */}
      <div className="payment-form-row"> 
        <div className="payment-form-group flex-1">
          <label className="payment-label">Invoice Number</label>
          <input className="payment-input" readOnly value={payment.inv_number || ""} />
        </div>

        <div className="payment-form-group flex-1">
          <label className="payment-label">Balance Paid</label>
          <div className="payment-input-with-symbol"> 
            <input 
              className="payment-input" 
              readOnly 
              value={`₱ ${parseFloat(payment.amount_paid).toLocaleString("en-PH", { minimumFractionDigits: 2 })}`} 
            />
          </div>
        </div>
      </div>

      <div className="payment-form-group">
        <label className="payment-label">Date of Payment</label>
        <input className="payment-input" readOnly value={payment.date_paid} />
      </div>

      <div className="payment-form-group">
        <label className="payment-label">Proof of Payment</label>
        <div className="file-display">
          {payment.proof_payment_url ? (
            <a href={payment.proof_payment_url} target="_blank" className="file-link">
              View Proof of Payment
            </a>
          ) : "No file uploaded"}
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="payment-button-row">
        <button className="payment-cancel-btn" onClick={() => navigate("/credit-manager/dashboard")}>
          Cancel
        </button>
        <button className="payment-confirm-btn" onClick={() => initiateAction("approve")}>
          Confirm Payment
        </button>
      </div>

      {/* Modals remain structurally similar but use CSS classes */}
      {showPasswordModal && (
        <div className="modal-overlay">
          <div className="payment-modal">
            <h3 className="section-title">Please enter user password to proceed.</h3>
            <input
              type="password"
              className="password-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••"
            />
            <div className="payment-button-row">
              <button className="payment-cancel-btn" onClick={handleCancelPasswordModal}>Cancel</button>
              <button className="payment-confirm-btn" onClick={handleConfirmAction}>Confirm Payment</button>
            </div>
          </div>
        </div>
      )}

      {showSuccessModal && (
        <div className="modal-overlay">
          <div className="payment-modal">
            <h3 className="success-section-title" style={{textAlign: 'center'}}>Balance payment successfully updated!</h3>
            <p className="success-message">Balance payment has been confirmed and credit balance updated.</p>
            <button className="payment-return-btn" onClick={() => navigate("/credit-manager/dashboard")}>
              Return to Dashboard
            </button>
          </div>
        </div>
      )}
      </main>
    </div>
  );
}